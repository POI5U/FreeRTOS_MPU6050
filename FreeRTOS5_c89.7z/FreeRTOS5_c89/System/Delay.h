#ifndef __DELAY_H
#define __DELAY_H

//void Delay_us(uint32_t us);
void Delay_ms(uint32_t ms);
void Delay_s(uint32_t s);

void CLK_Delay_us(uint32_t xus);
void CLK_Delay_ms(uint32_t xms);
void CLK_Delay_s(uint32_t xs);
	
#endif
